from rlbot.agents.base_agent import BaseAgent, SimpleControllerState
from rlbot.messages.flat.QuickChatSelection import QuickChatSelection
from rlbot.utils.structures.game_data_struct import GameTickPacket

from util.ball_prediction_analysis import find_slice_at_time
from util.boost_pad_tracker import BoostPadTracker
from util.drive import steer_toward_target
from util.sequence import Sequence, ControlStep
from util.vec import Vec3
from rlbot.utils.game_state_util import GameState, BallState, CarState, Physics, Vector3, Rotator, GameInfoState

import numpy as np

class MyBot(BaseAgent):

    def __init__(self, name, team, index):
        super().__init__(name, team, index)
        self.active_sequence: Sequence = None
        self.boost_pad_tracker = BoostPadTracker()
        self.mode = "Replay"
        # self.mode = "Collect"
        self.pos = 0
        self.prev_frame = 0
        self.saved_data = []
        '''
        Collect = Collect data from a human player

        '''

    def initialize_agent(self):
        self.boost_pad_tracker.initialize_boosts(self.get_field_info())

    def get_output(self, packet: GameTickPacket) -> SimpleControllerState:
        self.boost_pad_tracker.update_boost_status(packet)

        if self.active_sequence is not None and not self.active_sequence.done:
            controls = self.active_sequence.tick(packet)
            if controls is not None:
                return controls

        my_car = packet.game_cars[self.index]
        other_car = packet.game_cars[1 - self.index]
        if self.mode == "Replay":
            car_location = Vec3(my_car.physics.location)
            car_velocity = Vec3(my_car.physics.velocity)
            car_rotation = my_car.physics.rotation
            car_boost = my_car.boost
        elif self.mode == "Collect":
            car_location = Vec3(other_car.physics.location)
            car_velocity = Vec3(other_car.physics.velocity)
            car_rotation = other_car.physics.rotation
            car_boost = other_car.boost
        ball_location = Vec3(packet.game_ball.physics.location)
        ball_velocity = Vec3(packet.game_ball.physics.velocity)
        ball_rotation = packet.game_ball.physics.rotation

        if self.mode == "Collect":
            if packet.game_info.is_round_active == True:
                self.saved_data.append([car_location.x, car_location.y, car_location.z, car_velocity.x, car_velocity.y, car_velocity.z, car_rotation.pitch, car_rotation.yaw, car_rotation.roll, ball_location.x, ball_location.y, ball_location.z, ball_velocity.x, ball_velocity.y, ball_velocity.z, ball_rotation.pitch, ball_rotation.yaw, ball_rotation.roll, car_boost, packet.game_info.frame_num])
            else:
                if self.saved_data != []:
                    self.saved_data = np.array(self.saved_data)
                    np.save("replay.npy", self.saved_data)
                    self.saved_data = []
        elif self.mode == "Replay":
            if packet.game_info.is_round_active == True:
                while packet.game_info.frame_num >= self.saved_data[self.pos][-1] >= self.prev_frame:
                    print(self.saved_data[self.pos][0])
                    car_state = CarState(physics = Physics(location = Vector3(self.saved_data[self.pos][0], self.saved_data[self.pos][1], self.saved_data[self.pos][2]), velocity = Vector3(self.saved_data[self.pos][3], self.saved_data[self.pos][4], self.saved_data[self.pos][5]), rotation = Rotator(self.saved_data[self.pos][6], self.saved_data[self.pos][7], self.saved_data[self.pos][8])))
                    ball_state = BallState(physics = Physics(location = Vector3(self.saved_data[self.pos][9], self.saved_data[self.pos][10], self.saved_data[self.pos][11]), velocity = Vector3(self.saved_data[self.pos][12], self.saved_data[self.pos][13], self.saved_data[self.pos][14]), rotation = Rotator(self.saved_data[self.pos][15], self.saved_data[self.pos][16], self.saved_data[self.pos][17])))
                    gs = GameState(cars={self.index: car_state}, ball = ball_state)
                    self.set_game_state(gs)
                    self.pos += 1
                self.prev_frame = packet.game_info.frame_num
            else:
                self.saved_data = np.load("replay.npy")

        controls = SimpleControllerState()
        return controls

    def begin_front_flip(self, packet):
        self.send_quick_chat(team_only=False, quick_chat=QuickChatSelection.Information_IGotIt)

        self.active_sequence = Sequence([
            ControlStep(duration=0.05, controls=SimpleControllerState(jump=True)),
            ControlStep(duration=0.05, controls=SimpleControllerState(jump=False)),
            ControlStep(duration=0.2, controls=SimpleControllerState(jump=True, pitch=-1)),
            ControlStep(duration=0.8, controls=SimpleControllerState()),
        ])

        return self.active_sequence.tick(packet)